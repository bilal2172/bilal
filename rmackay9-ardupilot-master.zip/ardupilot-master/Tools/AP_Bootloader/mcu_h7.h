/*
  MCU tables for STM32H7
 */

#if defined(STM32H7)

#define STM32_UNKNOWN	0

mcu_des_t mcu_descriptions[] = {
    { STM32_UNKNOWN,	"STM32H7?????",		'?'},
};

const mcu_rev_t silicon_revs[] = {
};

#endif // STM32H7

