"""Autotests tools suite"""
